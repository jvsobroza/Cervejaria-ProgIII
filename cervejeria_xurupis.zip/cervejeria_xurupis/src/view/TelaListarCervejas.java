package view;

import javax.swing.JPanel;

public class TelaListarCervejas extends JPanel {

	private static final long serialVersionUID = 1L;

	/**
	 * Create the panel.
	 */
	public TelaListarCervejas() {

	}

}
