package view;

import javax.swing.JPanel;
import java.awt.GridLayout;

public class TelaLogin extends JPanel {

	private static final long serialVersionUID = 1L;
	private JPanel panel;

	/**
	 * Create the panel.
	 */
	public TelaLogin() {

		initComponents();
	}
	private void initComponents() {setBounds(100, 100, 1102, 611);
		setLayout(new GridLayout(1, 0, 0, 0));
		
		this.panel = new JPanel();
		add(this.panel);
		this.panel.setLayout(new GridLayout(1, 0, 0, 0));
	}

}
